import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Home, Dumbbell, Trophy, Map, User, LogOut, BookOpen, X, Maximize2 } from 'lucide-react';
const navItems = [
 {path:'/dashboard',label:'Төв өргөө',icon:Home}, {path:'/workouts',label:'Бэлтгэлийн талбар',icon:Dumbbell},
 {path:'/quests',label:'Даалгавар',icon:Map}, {path:'/story',label:'Түүхийн ном',icon:BookOpen},
 {path:'/leaderboard',label:'Аваргуудын танхим',icon:Trophy}, {path:'/profile',label:'Баатар',icon:User}
];
export default function Navbar(){
 const {user,logout}=useAuth(); const location=useLocation(); const navigate=useNavigate(); const [mapOpen,setMapOpen]=useState(false);
 const leave=()=>{logout();navigate('/login')};
 return <><header className="game-topbar"><Link to="/dashboard" className="brand-mark"><span>ᛟ</span><b>FITLVL</b><small>МӨНХ ХӨХ ТЭНГЭРИЙН ДООРХ ЧОНО</small></Link><div className="top-hero"><span className="hero-gem">✦</span><div><b>{user?.username || 'Аялагч'}</b><small>LV. {user?.level || 1} · {user?.total_xp || 0} XP</small></div><div className="top-xp"><i style={{width:`${user?.xp_percentage || 0}%`}}/></div></div><button className="logout-rune" onClick={leave} title="Гарах"><LogOut size={19}/></button></header>
 <nav className="game-nav">{navItems.map(({path,label,icon:Icon})=>{const active=location.pathname===path;return <Link key={path} to={path} className={`game-nav-item ${active?'active':''}`}><Icon size={23}/><span>{label}</span></Link>})}<button className="nav-minimap" onClick={()=>setMapOpen(true)} aria-label="Газрын зургийг томоор нээх"><span className="minimap-label">ТАЛЫН ГАЗРЫН ЗУРАГ</span><img src="/images/steppe-map.png" alt="Тал нутгийн газрын зураг"/><span className="minimap-expand"><Maximize2 size={13}/> Томруулах</span></button></nav>{mapOpen&&<div className="map-modal-backdrop" onClick={()=>setMapOpen(false)}><section className="map-modal-frame" onClick={e=>e.stopPropagation()}><header><b>МӨНХ ХӨХ ТЭНГЭРИЙН ДООРХ НУТАГ</b><button onClick={()=>setMapOpen(false)} aria-label="Хаах"><X size={20}/></button></header><img src="/images/steppe-map.png" alt="Тал нутгийн дэлгэрэнгүй газрын зураг"/><footer>Талын зам · Өвөг дээдсийн нутаг</footer></section></div>}</>;
}
