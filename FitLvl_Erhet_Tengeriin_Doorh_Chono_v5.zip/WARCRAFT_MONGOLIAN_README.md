# FitLvl — Эрхэт тэнгэрийн доорх чоно

## Windows дээр ажиллуулах
1. ZIP-ийг задлаад төслийн үндсэн хавтсанд орно.
2. Backend:
   ```powershell
   python -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   python manage.py migrate
   python manage.py runserver
   ```
3. Frontend, шинэ terminal:
   ```powershell
   cd frontend
   npm install
   npm start
   ```

## Түүхийн бүлэг нэмэх / засах
Django admin руу `http://localhost:8000/admin/` хаягаар нэвтэрч **Story chapters** хэсгийг сонгоно.
- Chapter number: бүлгийн дараалал (пролог = 0)
- Title: бүлгийн нэр
- Unlock level: хэддүгээр түвшинд нээгдэх
- Content: зохиолын текст
- Is published: хэрэглэгчдэд харуулах эсэх

Бүлгүүдийн нээлтийн жишиг: Пролог LV.1, I бүлэг LV.3, II бүлэг LV.6, III бүлэг LV.15, IV бүлэг LV.18, V бүлэг LV.21.

## Шинэчлэлтүүд
- Даалгаврын ахиц нь бэлтгэл амжилттай дуусахад автоматаар тооцогдоно: нийт бэлтгэл, хүчний бэлтгэл, кардио, streak болон XP-ийн зорилтууд.
- Нэг бэлтгэлийг давхар дуусгах хүсэлт XP болон даалгаврын ахицыг дахин нэмэхгүй.
- Зүүн цэсний доод хэсэгт газрын зураг байрлана. Зураг дээр дарахад дэлгэцийн төвд томоор нээгдэнэ.
- Өгүүллэгийн нэр: **ЭРХЭТ ТЭНГЭРИЙН ДООРХ ЧОНО**. I ботийн нүүр зураг нь хүү, I бүлгийн зураг нь чоно, II бүлгийн зураг нь охин.
- I бүлэг LV.3, II бүлэг LV.6 түвшинд нээгдэнэ.
- I бүлгийн аудио хоёр хэсэгтэй. `frontend/public/audio/chono1.mp3` болон `chono2.mp3` файлуудыг уншлагын хэсгийн аудио тоглуулагчаас сонсоно.
- Нүүр хуудсан дээрх уриа: **Өөрийгөө ял.**

## Анхаарах зүйл
- Өгөгдлийн санг устгахгүй. `python manage.py migrate` нь зөвхөн StoryChapter хүснэгтийг нэмнэ.
- Илчлэгийн график нь workout session-д хадгалагдсан calories_burned утгыг харуулна. Энэ нь одоогийн backend-ийн тооцоолсон утга болохоос эмнэлгийн хэмжилт биш.
- Хэрэв танай ZIP-д `requirements.txt` байхгүй бол Django, djangorestframework, djangorestframework-simplejwt, django-cors-headers болон Pillow (ашиглаж байвал)-ийг төслийн тохирох хувилбараар суулгана.
