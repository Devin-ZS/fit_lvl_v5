from django.utils import timezone
from .models import Quest, UserQuest
from gamification.utils import award_xp


def record_workout_for_quests(user, session, workout_xp):
    """Advance quest objectives from a genuinely completed workout session."""
    # Ensure objectives exist even if the player starts a workout before opening the quests page.
    for quest in Quest.objects.filter(is_active=True):
        UserQuest.objects.get_or_create(user=user, quest=quest)

    template = session.template
    categories = set()
    if template:
        categories = set(template.exercises.values_list('category', flat=True))

    level_rewards = []
    for uq in UserQuest.objects.select_related('quest').filter(user=user, completed=False):
        req = uq.quest.requirement_type
        increment = 0
        if req == 'workout_count':
            increment = 1
        elif req == 'strength_workouts' and 'strength' in categories:
            increment = 1
        elif req == 'cardio_workouts' and 'cardio' in categories:
            increment = 1
        elif req == 'xp_earned':
            increment = max(0, int(workout_xp))
        elif req == 'streak':
            uq.progress = max(uq.progress, int(user.streak or 0))
        else:
            continue

        if increment:
            uq.progress = min(uq.quest.requirement_value, uq.progress + increment)
        if uq.progress >= uq.quest.requirement_value and not uq.completed:
            uq.completed = True
            uq.completed_at = timezone.now()
            level_rewards.extend(award_xp(user, uq.quest.xp_reward, f"Даалгавар биелүүлсэн: {uq.quest.name}"))
        uq.save(update_fields=['progress', 'completed', 'completed_at'])

    return level_rewards
