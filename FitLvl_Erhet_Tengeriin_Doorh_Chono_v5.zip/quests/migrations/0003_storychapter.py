from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [('quests', '0002_initial')]
    operations = [migrations.CreateModel(name='StoryChapter', fields=[('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),('title',models.CharField(max_length=200)),('chapter_number',models.PositiveIntegerField(default=0)),('unlock_level',models.PositiveIntegerField(default=1)),('content',models.TextField()),('is_published',models.BooleanField(default=True))], options={'ordering':['chapter_number']})]
