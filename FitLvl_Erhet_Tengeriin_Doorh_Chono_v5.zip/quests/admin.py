from django.contrib import admin
from .models import Quest, UserQuest
admin.site.register(Quest)
admin.site.register(UserQuest)

from .models import StoryChapter

@admin.register(StoryChapter)
class StoryChapterAdmin(admin.ModelAdmin):
    list_display = ('chapter_number', 'title', 'unlock_level', 'is_published')
    list_editable = ('unlock_level', 'is_published')
    ordering = ('chapter_number',)
