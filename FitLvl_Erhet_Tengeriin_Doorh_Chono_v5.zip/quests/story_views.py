from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import StoryChapter

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def story_chapters(request):
    rows = StoryChapter.objects.filter(is_published=True).values('id','title','chapter_number','unlock_level','content')
    return Response([{'id':x['id'],'title':x['title'],'number':x['chapter_number'],'unlock_level':x['unlock_level'],'content':x['content']} for x in rows])
